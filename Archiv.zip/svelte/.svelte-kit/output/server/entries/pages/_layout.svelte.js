import { c as create_ssr_component, a as add_attribute, v as validate_component } from "../../chunks/index2.js";
const ThemeToggle_svelte_svelte_type_style_lang = "";
const css$4 = {
  code: ".svelte-mhpili.svelte-mhpili{border:0;box-sizing:border-box;margin:0;padding:0}:root{--hue:223;--sat:10%;--hue2:223;--sat2:90%;--light2:60%;--primary:hsl(var(--hue2), var(--sat2), var(--light2));--trans-dur:0.3s;--trans-timing:ease-in-out;--trans-timing2:cubic-bezier(0.42, -1.84, 0.42, 1.84);--trans-timing3:cubic-bezier(0.42, 0, 0.42, 1.84);font-size:20px}button.svelte-mhpili.svelte-mhpili{font:1em/1.5 sans-serif}main.svelte-mhpili.svelte-mhpili{display:flex;flex-direction:column;width:100%;height:100%;transform:scale(0.2)}.col.svelte-mhpili.svelte-mhpili{display:flex;flex:1;padding:1.5em 0;min-height:13em;transition:all 1.5s ease}.btn.svelte-mhpili.svelte-mhpili{background-color:transparent;background-image:linear-gradient(\n			hsl(var(--hue), var(--sat), 80%),\n			hsl(var(--hue), var(--sat), 85%)\n		);border-radius:50%;box-shadow:0 0 0 0.125em hsla(var(--hue2), var(--sat2), 50%, 0),\n			0 0 0.25em hsl(var(--hue), var(--sat), 55%) inset,\n			0 0.125em 0.125em hsl(var(--hue), var(--sat), 90%);cursor:pointer;margin:auto;outline:transparent;position:relative;width:10em;height:10em;transition:box-shadow var(--trans-dur) var(--trans-timing);-webkit-tap-highlight-color:transparent}.btn.svelte-mhpili.svelte-mhpili:focus-visible{box-shadow:0 0 0 0.125em hsla(var(--hue2), var(--sat2), 50%, 1),\n			0 0 0.25em hsl(var(--hue), var(--sat), 55%) inset,\n			0 0.125em 0.125em hsl(var(--hue), var(--sat), 90%)}.btn.svelte-mhpili.svelte-mhpili:before,.btn.svelte-mhpili.svelte-mhpili:after{border-radius:inherit;content:'';display:block;position:absolute}.btn.svelte-mhpili.svelte-mhpili:before{background-image:linear-gradient(\n			hsl(var(--hue), var(--sat), 90%),\n			hsl(var(--hue), var(--sat), 80%)\n		);box-shadow:0 0.75em 0.75em 0.25em hsla(var(--hue), 0%, 0%, 0.3);top:1.5em;left:1.5em;width:7em;height:7em;transition:box-shadow var(--trans-dur) var(--trans-timing2),\n			transform var(--trans-dur) var(--trans-timing2)}.btn.svelte-mhpili.svelte-mhpili:after{background-color:hsl(var(--hue), var(--sat), 75%);background-image:linear-gradient(\n			hsla(var(--hue), var(--sat), 90%, 0),\n			hsl(var(--hue), var(--sat), 90%)\n		);box-shadow:0 0.0625em 0 hsl(var(--hue), var(--sat), 90%) inset,\n			0 -0.0625em 0 hsl(var(--hue), var(--sat), 90%) inset,\n			0 0 0 0 hsla(var(--hue2), var(--sat2), var(--light2), 0.1) inset;top:3em;left:3em;width:4em;height:4em;transition:background-color var(--trans-dur) var(--trans-timing),\n			box-shadow var(--trans-dur) var(--trans-timing),\n			transform var(--trans-dur) var(--trans-timing2)}.btn__icon.svelte-mhpili.svelte-mhpili{display:block;position:absolute;top:calc(50% - 0.75em);left:calc(50% - 0.75em);width:1.5em;height:1.5em;transition:filter var(--trans-dur) var(--trans-timing);z-index:1}.btn__icon.svelte-mhpili g.svelte-mhpili{stroke:hsl(var(--hue), var(--sat), 70%);transition:stroke var(--trans-dur) var(--trans-timing)}.btn__sr.svelte-mhpili.svelte-mhpili{overflow:hidden;position:absolute;width:1px;height:1px}.btn[aria-pressed='true']:before,.btn[aria-pressed='true']:after,.btn[aria-pressed='true'] .btn__icon.svelte-mhpili.svelte-mhpili{transform:scale(0.98)}.btn[aria-pressed='true']:before{box-shadow:0 0.375em 0.375em 0 hsla(var(--hue), 0%, 0%, 0.3);transition-timing-function:var(--trans-timing3)}.btn[aria-pressed='true']:after{background-color:hsl(var(--hue), var(--sat), 90%);box-shadow:0 0.0625em 0 hsla(var(--hue2), var(--sat2), var(--light2), 0.5) inset,\n			0 -0.0625em 0 hsla(var(--hue2), var(--sat2), var(--light2), 0.5) inset,\n			0 0 0.75em 0.25em hsla(var(--hue2), var(--sat2), var(--light2), 0.1) inset;transition-timing-function:var(--trans-timing), var(--trans-timing), var(--trans-timing3)}.btn[aria-pressed='true'] .btn__icon.svelte-mhpili.svelte-mhpili{filter:drop-shadow(0 0 0.25em var(--primary))}.btn[aria-pressed='true'] .btn__icon.svelte-mhpili g.svelte-mhpili{stroke:var(--primary)}.col--dark.svelte-mhpili .btn.svelte-mhpili{background-image:linear-gradient(\n			hsl(var(--hue), var(--sat), 10%),\n			hsl(var(--hue), var(--sat), 15%)\n		);box-shadow:0 0 0 0.125em hsla(var(--hue2), var(--sat2), 50%, 0),\n			0 0 0.25em hsl(var(--hue), var(--sat), 5%) inset,\n			0 0.125em 0.125em hsl(var(--hue), var(--sat), 25%)}.col--dark.svelte-mhpili .btn.svelte-mhpili:focus-visible{box-shadow:0 0 0 0.125em hsla(var(--hue2), var(--sat2), 50%, 1),\n			0 0 0.25em hsl(var(--hue), var(--sat), 5%) inset,\n			0 0.125em 0.125em hsl(var(--hue), var(--sat), 25%)}.col--dark.svelte-mhpili .btn.svelte-mhpili:before{background-image:linear-gradient(\n			hsl(var(--hue), var(--sat), 20%),\n			hsl(var(--hue), var(--sat), 10%)\n		);box-shadow:0 0.75em 0.75em 0.25em hsla(var(--hue), 0%, 0%, 0.7)}.col--dark.svelte-mhpili .btn.svelte-mhpili:after{background-color:hsl(var(--hue), var(--sat), 10%);background-image:linear-gradient(\n			hsla(var(--hue), var(--sat), 20%, 0),\n			hsl(var(--hue), var(--sat), 20%)\n		);box-shadow:0 0.0625em 0 hsl(var(--hue), var(--sat), 25%) inset,\n			0 -0.0625em 0 hsl(var(--hue), var(--sat), 25%) inset,\n			0 0 0 0 hsla(var(--hue2), var(--sat2), var(--light2), 0.1) inset}.col--dark.svelte-mhpili .btn__icon g.svelte-mhpili{stroke:hsl(var(--hue), var(--sat), 5%)}.col--dark.svelte-mhpili .btn[aria-pressed='true']:before{box-shadow:0 0.375em 0.375em 0 hsla(var(--hue), 0%, 0%, 0.7)}.col--dark.svelte-mhpili .btn[aria-pressed='true']:after{background-color:hsl(var(--hue), var(--sat), 20%);box-shadow:0 0.0625em 0 hsla(var(--hue2), var(--sat2), var(--light2), 0.5) inset,\n			0 -0.0625em 0 hsla(var(--hue2), var(--sat2), var(--light2), 0.5) inset,\n			0 0 0.75em 0.25em hsla(var(--hue2), var(--sat2), var(--light2), 0.1) inset}",
  map: null
};
const ThemeToggle = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let toggleButton;
  let toggleButtonWrapper;
  $$result.css.add(css$4);
  return `<main class="svelte-mhpili">
	<div class="col col--dark svelte-mhpili"${add_attribute("this", toggleButtonWrapper, 0)}><button id="btn2" class="btn svelte-mhpili" type="button" aria-pressed="false"${add_attribute("this", toggleButton, 0)}><svg class="btn__icon svelte-mhpili" viewBox="0 0 24 24" width="24px" height="24px" aria-hidden="true"><g stroke="currentColor" stroke-width="2" stroke-linecap="round" class="svelte-mhpili"><polyline points="12,1 12,10" class="svelte-mhpili"></polyline><circle fill="none" cx="12" cy="13" r="9" stroke-dasharray="49.48 7.07" stroke-dashoffset="10.6" class="svelte-mhpili"></circle></g></svg>
			<span class="btn__sr svelte-mhpili">Power (Dark)</span></button></div>
</main>`;
});
const Hamburger_svelte_svelte_type_style_lang = "";
const css$3 = {
  code: ":root{--hamburger-width:40px;--hamburger-height:calc(var(--hamburger-width) / 1.5)}button.svelte-1page15.svelte-1page15{background:none;border:none;padding:0;font:inherit;cursor:pointer;outline:inherit}#hamburger.svelte-1page15.svelte-1page15{width:var(--hamburger-width);height:var(--hamburger-height);position:relative;margin:50px auto;transform:rotate(0deg);transition:0.5s ease-in-out;cursor:pointer}#hamburger.svelte-1page15 span.svelte-1page15{display:block;position:absolute;height:calc(var(--hamburger-height) / 7);width:100%;background:var(--text-color-secondary);border-radius:calc(var(--hamburger-height) / 5);opacity:1;left:0;transform:rotate(0deg);transition:0.25s ease-in-out}#hamburger.svelte-1page15:hover span.svelte-1page15,#hamburger.open span.svelte-1page15.svelte-1page15{background:var(--color-svelte);filter:brightness(0.8)}#hamburger.svelte-1page15 span.svelte-1page15:nth-child(1){top:0px}#hamburger.svelte-1page15 span.svelte-1page15:nth-child(2),#hamburger.svelte-1page15 span.svelte-1page15:nth-child(3){top:calc(var(--hamburger-height) / 3)}#hamburger.svelte-1page15 span.svelte-1page15:nth-child(4){top:calc(var(--hamburger-height) / 3 * 2)}#hamburger.open span.svelte-1page15.svelte-1page15:nth-child(1){top:calc(var(--hamburger-height) / 3);width:0%;left:50%}#hamburger.open span.svelte-1page15.svelte-1page15:nth-child(2){transform:rotate(45deg)}#hamburger.open span.svelte-1page15.svelte-1page15:nth-child(3){transform:rotate(-45deg)}#hamburger.open span.svelte-1page15.svelte-1page15:nth-child(4){top:calc(var(--hamburger-height) / 3);width:0%;left:50%}",
  map: null
};
const Hamburger = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { open = false } = $$props;
  let { onClick = () => {
    open = !open;
  } } = $$props;
  if ($$props.open === void 0 && $$bindings.open && open !== void 0)
    $$bindings.open(open);
  if ($$props.onClick === void 0 && $$bindings.onClick && onClick !== void 0)
    $$bindings.onClick(onClick);
  $$result.css.add(css$3);
  return `<button${add_attribute("aria-expanded", open, 0)} aria-label="toggle menu" id="hamburger" class="${["svelte-1page15", open ? "open" : ""].join(" ").trim()}"><span class="svelte-1page15"></span>
	<span class="svelte-1page15"></span>
	<span class="svelte-1page15"></span>
	<span class="svelte-1page15"></span>
</button>`;
});
const Header_svelte_svelte_type_style_lang = "";
const css$2 = {
  code: "header.svelte-1dsp1pm{display:flex;justify-content:space-between;align-items:center}.pagename.svelte-1dsp1pm{font-size:1.75rem}.header_right.svelte-1dsp1pm{position:relative}nav.svelte-1dsp1pm{position:absolute;top:5rem;right:0;z-index:10;width:max-content;padding:0.25rem 1rem;background-color:var(--bg-color-secondary);border:1px solid var(--color-border);border-radius:var(--border-radius-m)}ul.svelte-1dsp1pm{list-style:none;padding:0;margin:0}li.svelte-1dsp1pm{margin:0.5rem 0}button.svelte-1dsp1pm{color:var(--text-color-secondary);transition:all 0.2s ease-in-out}button.svelte-1dsp1pm:hover{color:var(--color-svelte)}",
  map: null
};
const Header = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { open = false } = $$props;
  let { onClick = () => {
    open = !open;
  } } = $$props;
  if ($$props.open === void 0 && $$bindings.open && open !== void 0)
    $$bindings.open(open);
  if ($$props.onClick === void 0 && $$bindings.onClick && onClick !== void 0)
    $$bindings.onClick(onClick);
  $$result.css.add(css$2);
  return `${$$result.head += `<!-- HEAD_svelte-jisam2_START -->${$$result.title = `<title>Skanban</title>`, ""}<meta name="description" content="Svelte demo app"><!-- HEAD_svelte-jisam2_END -->`, ""}

<header class="svelte-1dsp1pm"><div class="header_left"></div>
	<div class="header_center"><span class="pagename svelte-1dsp1pm">Skanban </span></div>
	<div class="header_right svelte-1dsp1pm">${validate_component(Hamburger, "Hamburger").$$render($$result, { open, onClick }, {}, {})}
		${open ? `<nav class="svelte-1dsp1pm">
				<ul class="svelte-1dsp1pm"><li class="svelte-1dsp1pm"><button class="styleLessButton svelte-1dsp1pm">new Column</button></li>
					<li class="svelte-1dsp1pm"><button class="styleLessButton svelte-1dsp1pm">${validate_component(ThemeToggle, "ThemeToggle").$$render($$result, {}, {}, {})}</button></li>
					<li class="svelte-1dsp1pm"><button class="styleLessButton svelte-1dsp1pm">...</button></li></ul></nav>` : ``}</div>
</header>`;
});
const Footer_svelte_svelte_type_style_lang = "";
const css$1 = {
  code: "footer.svelte-1wjwu9e{display:flex;justify-content:space-between;align-items:center}.copyright.svelte-1wjwu9e{font-size:0.9rem}",
  map: null
};
const Footer = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css$1);
  return `<footer class="svelte-1wjwu9e"><div class="footer_left"><a href="https://dev.rasal.de/skanban/api.php?init" target="_blank">reset</a>
		<a href="https://dev.rasal.de/skanban/api.php?dummy=10" target="_blank">dummy</a></div>
	<div class="footer_center"><span class="copyright svelte-1wjwu9e">SvelteMate </span></div>
	<div class="footer_right"></div>
</footer>`;
});
const tooltip = "";
const styles = "";
const _layout_svelte_svelte_type_style_lang = "";
const css = {
  code: "#SKA > header{width:100%;max-width:var(--max-width);height:var(--header-height);padding:0;margin:0 auto;background-color:var(--bg-color-primary);color:var(--color-svelte)}#SKA>main.svelte-8doyso{width:100%;max-width:var(--max-width);height:var(--main-height);padding:0;margin:0 auto;background-color:var(--bg-color-primary)}#SKA > footer{width:100%;max-width:var(--max-width);height:var(--footer-height);padding:0;margin:0 auto;background-color:var(--bg-color-primary);color:var(--color-text)}",
  map: null
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${validate_component(Header, "Header").$$render($$result, {}, {}, {})}

<main class="svelte-8doyso">${slots.default ? slots.default({}) : ``}</main>

${validate_component(Footer, "Footer").$$render($$result, {}, {}, {})}`;
});
export {
  Layout as default
};
