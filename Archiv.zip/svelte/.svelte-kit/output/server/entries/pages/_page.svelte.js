import { c as create_ssr_component, e as escape, a as add_attribute, b as subscribe, v as validate_component, d as each, f as set_store_value } from "../../chunks/index2.js";
import { w as writable } from "../../chunks/index.js";
import "svelte-animated-details";
function formatDatetime(datetime) {
  const date = new Date(datetime);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  date.getSeconds();
  return `${day}.${month}.${year} ${hours}:${minutes}`;
}
const topicStore = writable(0);
const Topics_svelte_svelte_type_style_lang = "";
const css$3 = {
  code: ".topicWrapper.svelte-aw8d0q.svelte-aw8d0q{overflow:hidden;border:1px solid var(--color-border);border-radius:var(--border-radius-m)}.topicHeader.svelte-aw8d0q.svelte-aw8d0q{position:relative;display:flex;justify-content:space-between;align-items:center;cursor:pointer;padding:0.25rem;padding-inline:0.5rem;padding-top:0.4rem;border-bottom:1px solid var(--color-border);margin-bottom:-1px;background-color:var(--bg-color-secondary)}.topicHeader.svelte-aw8d0q.svelte-aw8d0q::-webkit-details-marker{display:none}.topicTitleWrapper.svelte-aw8d0q.svelte-aw8d0q{font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:1rem;height:1.5rem;transition:all 0.2s;color:var(--color-text-secondary)}.topicTitle.svelte-aw8d0q.svelte-aw8d0q{color:var(--color-text)}.manageTopic.svelte-aw8d0q.svelte-aw8d0q{right:0.5rem;top:0.5rem;z-index:10;pointer-events:none;display:none}.topicWrapper[open] .manageTopic.svelte-aw8d0q.svelte-aw8d0q{display:block}.topicWrapper.svelte-aw8d0q>p.svelte-aw8d0q{padding-inline:0.5rem}.topicDate.svelte-aw8d0q.svelte-aw8d0q{font-size:0.8rem}.topicContentMain.svelte-aw8d0q.svelte-aw8d0q{padding-bottom:0.5rem}.topicContentFooter.svelte-aw8d0q.svelte-aw8d0q{font-size:0.8rem}",
  map: null
};
const Topics = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { topic } = $$props;
  if ($$props.topic === void 0 && $$bindings.topic && topic !== void 0)
    $$bindings.topic(topic);
  $$result.css.add(css$3);
  return `<details id="${"topic_" + escape(topic.id, true)}" class="topicWrapper svelte-aw8d0q"><summary class="topicHeader svelte-aw8d0q"><span class="topicTitleWrapper svelte-aw8d0q"><span class="topicTitle svelte-aw8d0q" style="${"color:" + escape(topic.color, true)}">${escape(topic.title)}</span></span>
		<span class="topicDate svelte-aw8d0q"${add_attribute("title", formatDatetime(topic.created), 0)}>${escape(formatDatetime(topic.created).split(" ")[0])}</span></summary>
	<div class="manageTopic svelte-aw8d0q"><span class="editTopic">x</span>
		<span class="deleteTopic">x</span></div>
	<p class="topicContentMain svelte-aw8d0q">${escape(topic.content)}</p>
	<p class="topicContentFooter svelte-aw8d0q">${escape(topic.author)}</p>
</details>`;
});
const ColorPicker_svelte_svelte_type_style_lang = "";
const css$2 = {
  code: ".wrapper.svelte-1txktx0{position:relative}.colorValueInput.svelte-1txktx0{height:2rem;padding:0.25rem;width:2rem}.colors.svelte-1txktx0{position:absolute;top:-2rem;left:0;display:grid;grid-template-columns:var(--grid-template-columns);gap:0.25rem;border:1px solid var(--color-border);border-radius:var(--border-radius-m);padding:0.5rem;background-color:var(--bg-color-primary)}button.svelte-1txktx0{background-color:transparent;border:1px solid var(--color-border);border-radius:var(--border-radius-m);padding:0.25rem 0.5rem;width:1.5rem;height:1.5rem;cursor:pointer}",
  map: null
};
const ColorPicker = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let colorValue = "#abb2bf";
  let colorName = "white1";
  $$result.css.add(css$2);
  return `<div class="wrapper svelte-1txktx0"><input type="color" name="color" class="colorValueInput svelte-1txktx0"${add_attribute("value", colorValue, 0)}>
	<input type="hidden" name="colorName"${add_attribute("value", colorName, 0)}>

	${``}
</div>`;
});
const Plus = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect><path d="M12 8v8m-4-4h8"></path></g></svg>`;
});
const Close = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 9l3 3m0 0l3 3m-3-3l-3 3m3-3l3-3M4 16.8V7.2c0-1.12 0-1.68.218-2.108c.192-.377.497-.682.874-.874C5.52 4 6.08 4 7.2 4h9.6c1.12 0 1.68 0 2.108.218a2 2 0 0 1 .874.874C20 5.52 20 6.08 20 7.2v9.6c0 1.12 0 1.68-.218 2.108a2.001 2.001 0 0 1-.874.874c-.428.218-.986.218-2.104.218H7.197c-1.118 0-1.678 0-2.105-.218a2 2 0 0 1-.874-.874C4 18.48 4 17.92 4 16.8Z"></path></svg>`;
});
const NewTopic_svelte_svelte_type_style_lang = "";
const css$1 = {
  code: ".flex.svelte-1rrm272.svelte-1rrm272{display:flex;flex-direction:row;gap:0.5rem}.openNewTopicButton.svelte-1rrm272 svg g{stroke:var(--malibu);transition:all 0.2s;filter:brightness(0.6)}.openNewTopicButton.svelte-1rrm272:hover svg g{filter:brightness(1)}.newTopic_header.svelte-1rrm272.svelte-1rrm272{display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding:0.5rem}.newTopic_header.svelte-1rrm272 h2.svelte-1rrm272{color:var(--color-text);text-align:center;font-size:1.2rem;margin:0}.newTopic_form.svelte-1rrm272.svelte-1rrm272{display:flex;flex-direction:column;gap:0.5rem;padding:0.5rem}.newTopicFormDialog.svelte-1rrm272.svelte-1rrm272{max-width:30rem}.closeNewTopicButton.svelte-1rrm272.svelte-1rrm272{top:0.5rem;right:0.5rem}.closeNewTopicButton.svelte-1rrm272 svg path{stroke:var(--malibu);transition:all 0.2s}.closeNewTopicButton.svelte-1rrm272:hover svg path{filter:brightness(1.2)}.newTopicMissingInput.svelte-1rrm272.svelte-1rrm272{padding-left:1rem;color:var(--error)}textarea.svelte-1rrm272.svelte-1rrm272{height:5rem}",
  map: null
};
const NewTopic = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_topicStore;
  $$unsubscribe_topicStore = subscribe(topicStore, (value) => value);
  let { columnId } = $$props;
  let { columns } = $$props;
  let formDialog, authorName;
  let missingInput = "";
  if ($$props.columnId === void 0 && $$bindings.columnId && columnId !== void 0)
    $$bindings.columnId(columnId);
  if ($$props.columns === void 0 && $$bindings.columns && columns !== void 0)
    $$bindings.columns(columns);
  $$result.css.add(css$1);
  $$unsubscribe_topicStore();
  return `<button class="openNewTopicButton styleLessButton svelte-1rrm272" title="add new Topic">${validate_component(Plus, "Plus").$$render($$result, {}, {}, {})}</button>

<dialog class="newTopicFormDialog svelte-1rrm272"${add_attribute("this", formDialog, 0)}><div class="innerDialog"><form class="newTopic_form svelte-1rrm272"><header class="newTopic_header svelte-1rrm272"><h2 class="svelte-1rrm272">New Topic in
					<select name="column">${each(columns, (column) => {
    return `<option${add_attribute("value", column.id, 0)} ${column.id === columnId ? "selected" : ""}>${escape(column.column_name)}
							</option>`;
  })}</select></h2>
				<button class="closeNewTopicButton styleLessButton svelte-1rrm272" title="close Form">${validate_component(Close, "Close").$$render($$result, {}, {}, {})}</button></header>

			<div class="flex svelte-1rrm272"><input type="text" name="title" placeholder="Topic title" value="title">
				${validate_component(ColorPicker, "ColorPicker").$$render($$result, {}, {}, {})}</div>

			<textarea name="content" placeholder="Topic content" class="svelte-1rrm272">text</textarea>
			<input type="text" name="author" placeholder="Name"${add_attribute("value", authorName, 0)}>
			<footer class="newTopic_footer"><input type="submit" value="submit">
				<span class="newTopicMissingInput svelte-1rrm272">${escape(missingInput)}</span></footer></form></div>
</dialog>`;
});
const MoveH = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12h18M3 12l3 3m-3-3l3-3m15 3l-3-3m3 3l-3 3"></path></svg>`;
});
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: ".columns.svelte-1kzyid.svelte-1kzyid{height:100%;display:flex;flex-direction:row;flex-wrap:nowrap;gap:1rem;padding-inline:0.5rem;overflow-x:auto;transition:all 0.2s}.columns.svelte-1kzyid.svelte-1kzyid.active{transform:scale(1)}.column.svelte-1kzyid.svelte-1kzyid{min-width:365px;max-width:100%;min-height:0;max-height:100%;margin:0;padding:0}.column_header.svelte-1kzyid.svelte-1kzyid{position:relative;display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding-inline:0.5rem}.dragHandle.svelte-1kzyid path{stroke:var(--color-text-secondary);filter:brightness(0.5);transition:all 0.2s}.dragHandle.svelte-1kzyid:hover path{stroke:var(--color-text);filter:brightness(1)}.column_header.svelte-1kzyid h2.svelte-1kzyid{margin-block:0rem;padding-block:0.25rem;text-align:center;-webkit-user-select:none;-ms-user-select:none;user-select:none;cursor:grab;transition:all 0.2s;color:var(--color-text-secondary)}.newTopic.svelte-1kzyid svg{filter:brightness(0.7)}.columns.svelte-1kzyid.active .column_header h2.svelte-1kzyid{filter:brightness(1.4);cursor:grabbing;cursor:-webkit-grabbing}.column_content.svelte-1kzyid.svelte-1kzyid{list-style:none;padding-inline:0.25rem;min-height:2rem;display:flex;flex-direction:column;gap:0.5rem}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $topicStore, $$unsubscribe_topicStore;
  $$unsubscribe_topicStore = subscribe(topicStore, (value) => $topicStore = value);
  let { data } = $$props;
  set_store_value(topicStore, $topicStore = data.data, $topicStore);
  let sliderColumns;
  let sliderHandle;
  let draggedColumn;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$result.css.add(css);
  $$unsubscribe_topicStore();
  return `

${$topicStore ? `<section class="columns svelte-1kzyid"${add_attribute("this", sliderColumns, 0)}>${each($topicStore, (column) => {
    return `<article class="column svelte-1kzyid" id="${"column_" + escape(column.id, true)}"${add_attribute("this", draggedColumn, 0)}><header class="column_header svelte-1kzyid"><div aria-label="drag-handle" class="dragHandle svelte-1kzyid"${add_attribute("style", "cursor: grab", 0)}>${validate_component(MoveH, "MoveH").$$render($$result, {}, {}, {})}</div>
					<h2 style="${"color:" + escape(column.color, true)}" class="svelte-1kzyid"${add_attribute("this", sliderHandle, 0)}>${escape(column.column_name)}</h2>
					<div class="newTopic svelte-1kzyid">${validate_component(NewTopic, "NewTopic").$$render(
      $$result,
      {
        columnId: column.id,
        columns: $topicStore
      },
      {},
      {}
    )}
					</div></header>

				<ul class="column_content svelte-1kzyid">${each(column.topics, (topic) => {
      return `<li>${validate_component(Topics, "Topics").$$render($$result, { topic }, {}, {})}
						</li>`;
    })}</ul>
			</article>`;
  })}</section>` : ``}`;
});
export {
  Page as default
};
