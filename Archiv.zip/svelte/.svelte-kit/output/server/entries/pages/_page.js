import { b as building } from "../../chunks/environment.js";
const PUBLIC_API_URL = "https://dev.rasal.de/skanban/api.php?";
const prerender = true;
const ssr = true;
const load = async ({ fetch }) => {
  if (building)
    return;
  const response = await fetch(PUBLIC_API_URL + "start");
  let data = await response.json();
  return { data };
};
export {
  load,
  prerender,
  ssr
};
