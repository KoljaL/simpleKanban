const ssr = false;
export {
  ssr
};
