let building = false;
function set_building() {
  building = true;
}
export {
  building as b,
  set_building as s
};
