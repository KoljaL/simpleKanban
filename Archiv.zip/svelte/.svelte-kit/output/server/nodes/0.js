import * as universal from '../entries/pages/_layout.js';

export const index = 0;
export const component = async () => (await import('../entries/pages/_layout.svelte.js')).default;
export const file = '_app/immutable/entry/_layout.svelte.bc01fd49.js';
export { universal };
export const universal_id = "src/routes/+layout.js";
export const imports = ["_app/immutable/entry/_layout.svelte.bc01fd49.js","_app/immutable/chunks/index.c024ba4b.js","_app/immutable/chunks/utils.632edf89.js","_app/immutable/entry/_layout.js.7dbd68f0.js","_app/immutable/chunks/_layout.e4a84b88.js"];
export const stylesheets = ["_app/immutable/assets/_layout.0abb3f4a.css"];
export const fonts = ["Overpass-Light.woff2"];
