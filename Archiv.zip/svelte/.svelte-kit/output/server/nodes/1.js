

export const index = 1;
export const component = async () => (await import('../entries/fallbacks/error.svelte.js')).default;
export const file = '_app/immutable/entry/error.svelte.e852d811.js';
export const imports = ["_app/immutable/entry/error.svelte.e852d811.js","_app/immutable/chunks/index.c024ba4b.js","_app/immutable/chunks/singletons.049b1e83.js","_app/immutable/chunks/index.71329fe5.js"];
export const stylesheets = [];
export const fonts = [];
