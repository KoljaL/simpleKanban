import * as universal from '../entries/pages/_page.js';

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export const file = '_app/immutable/entry/_page.svelte.520b410f.js';
export { universal };
export const universal_id = "src/routes/+page.js";
export const imports = ["_app/immutable/entry/_page.svelte.520b410f.js","_app/immutable/chunks/index.c024ba4b.js","_app/immutable/chunks/public.decf1f9a.js","_app/immutable/chunks/index.71329fe5.js","_app/immutable/chunks/utils.632edf89.js","_app/immutable/entry/_page.js.eb3bc41e.js","_app/immutable/chunks/public.decf1f9a.js","_app/immutable/chunks/_page.2cc657c9.js"];
export const stylesheets = ["_app/immutable/assets/_page.2978d0d5.css"];
export const fonts = [];
