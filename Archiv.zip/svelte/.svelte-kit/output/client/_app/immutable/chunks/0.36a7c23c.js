import{_ as r}from"./_layout.e4a84b88.js";import{default as t}from"../entry/_layout.svelte.bc01fd49.js";export{t as component,r as universal};
