import{_ as r}from"./_page.2cc657c9.js";import{default as t}from"../entry/_page.svelte.520b410f.js";export{t as component,r as universal};
