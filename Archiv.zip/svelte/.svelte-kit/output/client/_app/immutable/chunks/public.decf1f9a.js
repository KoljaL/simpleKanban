const a="https://dev.rasal.de/skanban/api.php?";export{a as P};
