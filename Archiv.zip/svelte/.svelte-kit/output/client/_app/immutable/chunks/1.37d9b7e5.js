import{default as t}from"../entry/error.svelte.e852d811.js";export{t as component};
